const breadcrumb =document.querySelector("#breadcrumb");
breadcrumb.innerHTML =`	<div class="bg-white	 my-4">
    <!-- Breadcrumb -->
    <nav class="d-flex ">
    <div>

      <h6 class="mb-0">
        <a href="" class="text-reset">Home</a>
        <span><i class="fa-solid fa-terminal text-danger"></i></span>
        <a href="/src/views/productlist.html" class="text-reset">Analytics</a>
        <span><i class="fa-solid fa-terminal text-danger"></i></span>
        <a href="" class="text-reset "><b> Dashboard</b></a>
      </h6>

      <hr class="m-0"/>
      </div>
    </nav>
    <!-- Breadcrumb -->
  </div>`
